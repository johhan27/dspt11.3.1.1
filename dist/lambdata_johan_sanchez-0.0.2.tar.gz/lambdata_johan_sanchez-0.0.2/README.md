Guidelines for my software
